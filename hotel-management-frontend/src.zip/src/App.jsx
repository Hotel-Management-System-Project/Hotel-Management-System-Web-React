import { Component } from "react";

import {
  Navigate,
  Route,
  Routes,
} from "react-router-dom";

import {
  Alert,
  Box,
  Button,
  Paper,
  Typography,
} from "@mui/material";

import ErrorOutlineRoundedIcon from "@mui/icons-material/ErrorOutlineRounded";

import { useAuth } from "./context/AuthContext";

import Layout from "./components/Layout";

import Login from "./pages/Login";
import Signup from "./pages/Signup";


// Commented because these files do not exist yet

// import Dashboard from "./pages/Dashboard";
// import Hotels from "./pages/Hotels";
// import Rooms from "./pages/Rooms";
// import Bookings from "./pages/Bookings";
// import Users from "./pages/Users";
// import Settings from "./pages/Settings";

/* ================= ERROR BOUNDARY ================= */

class AppErrorBoundary extends Component {
  constructor(props) {
    super(props);

    this.state = {
      error: null,
    };
  }

  static getDerivedStateFromError(error) {
    return {
      error,
    };
  }

  componentDidCatch(error, info) {
    console.error(
      "StayFlow page error:",
      error,
      info
    );
  }

  handleReload = () => {
    window.location.reload();
  };

  handleLogin = () => {
    window.location.assign("/login");
  };

  render() {
    if (!this.state.error) {
      return this.props.children;
    }

    return (
      <Box
        sx={{
          minHeight: "100vh",
          display: "grid",
          placeItems: "center",
          px: 2,
          py: 4,
          background:
            "linear-gradient(135deg, #eff6ff 0%, #f8fafc 50%, #eef2ff 100%)",
        }}
      >
        <Paper
          elevation={0}
          sx={{
            width: "100%",
            maxWidth: 560,
            p: {
              xs: 3,
              sm: 5,
            },
            textAlign: "center",
            borderRadius: 5,
            border: "1px solid",
            borderColor: "divider",
          }}
        >
          <ErrorOutlineRoundedIcon
            color="error"
            sx={{
              fontSize: 60,
              mb: 2,
            }}
          />

          <Typography
            variant="h4"
            fontWeight={800}
          >
            Something went wrong
          </Typography>

          <Typography
            color="text.secondary"
            sx={{
              mt: 1.5,
              mb: 3,
            }}
          >
            StayFlow could not display this page.
          </Typography>

          <Alert
            severity="error"
            sx={{
              mb: 3,
              textAlign: "left",
            }}
          >
            {this.state.error?.message ||
              "Unexpected frontend error"}
          </Alert>

          <Box
            sx={{
              display: "flex",
              justifyContent: "center",
              gap: 2,
            }}
          >
            <Button
              variant="outlined"
              onClick={this.handleReload}
            >
              Reload page
            </Button>

            <Button
              variant="contained"
              onClick={this.handleLogin}
            >
              Go to login
            </Button>
          </Box>
        </Paper>
      </Box>
    );
  }
}

/* ================= PROTECTED ROUTE ================= */

function ProtectedRoute() {
  const { user } = useAuth();

  if (!user) {
    return (
      <Navigate
        to="/login"
        replace
      />
    );
  }

  return <Layout />;
}

/* ================= PUBLIC ROUTE ================= */

function PublicRoute({ children }) {
  const { user } = useAuth();

  if (user) {
    return (
      <Navigate
        to="/dashboard"
        replace
      />
    );
  }

  return children;
}

/* ================= TEMPORARY DASHBOARD ================= */

function TemporaryDashboard() {
  return (
    <Box sx={{ p: 4 }}>
      <Typography variant="h4">
        Dashboard
      </Typography>

      <Typography
        color="text.secondary"
        sx={{ mt: 1 }}
      >
        Dashboard page file is not created yet.
      </Typography>
    </Box>
  );
}

/* ================= APP ================= */

export default function App() {
  const { user } = useAuth();

  return (
    <AppErrorBoundary>
      <Routes>
        {/* Public Routes */}

        <Route
          path="/login"
          element={
            <PublicRoute>
              <Login />
            </PublicRoute>
          }
        />

        <Route
          path="/signup"
          element={
            <PublicRoute>
              <Signup />
            </PublicRoute>
          }
        />

        {/* Protected Routes */}

        <Route element={<ProtectedRoute />}>
          {/* Temporary dashboard */}

          <Route
            path="/dashboard"
            element={<TemporaryDashboard />}
          />

          {/* Uncomment after creating the files */}

          {/*
          <Route
            path="/dashboard"
            element={<Dashboard />}
          />

          <Route
            path="/hotels"
            element={<Hotels />}
          />

          <Route
            path="/rooms"
            element={<Rooms />}
          />

          <Route
            path="/bookings"
            element={<Bookings />}
          />

          <Route
            path="/users"
            element={<Users />}
          />

          <Route
            path="/settings"
            element={<Settings />}
          />
          */}
        </Route>

        {/* Default Route */}

        <Route
          path="/"
          element={
            <Navigate
              to={user ? "/dashboard" : "/login"}
              replace
            />
          }
        />

        {/* Invalid Route */}

        <Route
          path="*"
          element={
            <Navigate
              to={user ? "/dashboard" : "/login"}
              replace
            />
          }
        />
      </Routes>
    </AppErrorBoundary>
  );
}