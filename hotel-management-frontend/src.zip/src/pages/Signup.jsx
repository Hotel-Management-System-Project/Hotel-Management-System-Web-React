import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";

import {
  Alert,
  Box,
  Button,
  MenuItem,
  Paper,
  TextField,
  Typography,
} from "@mui/material";

import { endpoints } from "../services/api";

export default function Signup() {
  const [form, setForm] = useState({
    fullName: "",
    email: "",
    phone: "",
    password: "",
    role: "HOTEL_OWNER",
  });

  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const navigate = useNavigate();

  const submit = async (e) => {
    e.preventDefault();

    setBusy(true);
    setError("");

    try {
      await endpoints.signup(form);
      navigate("/login");
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="auth-shell">
      {/* Left Section */}
      <section className="auth-hero">
        <Box>
          <Typography variant="h5">
            StayFlow
          </Typography>
        </Box>

        <Box
          sx={{
            maxWidth: 580,
            zIndex: 1,
          }}
        >
          <Typography
            variant="h2"
            fontWeight={800}
          >
            Hospitality starts with clarity.
          </Typography>

          <Typography
            sx={{
              mt: 2,
              fontSize: 18,
              opacity: 0.82,
            }}
          >
            Create your workspace and bring
            properties, inventory, and bookings
            under one roof.
          </Typography>
        </Box>

        <Typography>
          Secure role-based onboarding
        </Typography>
      </section>

      {/* Right Section */}
      <section className="auth-form">
        <Paper
          elevation={0}
          sx={{
            width: "100%",
            maxWidth: 480,
            bgcolor: "transparent",
          }}
        >
          <Typography variant="h4">
            Create account
          </Typography>

          <Typography
            color="text.secondary"
            sx={{
              mt: 1,
              mb: 3,
            }}
          >
            Set up your StayFlow access in a
            minute.
          </Typography>

          {error && (
            <Alert
              severity="error"
              sx={{ mb: 2 }}
            >
              {error}
            </Alert>
          )}

          <Box
            component="form"
            onSubmit={submit}
            sx={{
              display: "grid",
              gap: 2,
            }}
          >
            <TextField
              required
              label="Full Name"
              value={form.fullName}
              onChange={(e) =>
                setForm({
                  ...form,
                  fullName: e.target.value,
                })
              }
            />

            <TextField
              required
              type="email"
              label="Email"
              value={form.email}
              onChange={(e) =>
                setForm({
                  ...form,
                  email: e.target.value,
                })
              }
            />

            <TextField
              required
              label="Phone"
              value={form.phone}
              onChange={(e) =>
                setForm({
                  ...form,
                  phone: e.target.value,
                })
              }
            />

            <TextField
              required
              type="password"
              label="Password"
              inputProps={{
                minLength: 6,
              }}
              value={form.password}
              onChange={(e) =>
                setForm({
                  ...form,
                  password: e.target.value,
                })
              }
            />

            <TextField
              select
              label="Account Type"
              value={form.role}
              onChange={(e) =>
                setForm({
                  ...form,
                  role: e.target.value,
                })
              }
            >
              <MenuItem value="HOTEL_OWNER">
                Hotel Owner
              </MenuItem>

              <MenuItem value="CUSTOMER">
                Customer
              </MenuItem>

              <MenuItem value="ADMIN">
                Administrator
              </MenuItem>
            </TextField>

            <Button
              size="large"
              variant="contained"
              type="submit"
              disabled={busy}
            >
              {busy
                ? "Creating..."
                : "Create Account"}
            </Button>
          </Box>

          <Typography
            textAlign="center"
            color="text.secondary"
            sx={{ mt: 3 }}
          >
            Already registered?{" "}
            <Link to="/login">
              Sign In
            </Link>
          </Typography>
        </Paper>
      </section>
    </div>
  );
}